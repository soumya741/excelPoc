package com.excel.poc.service;

import java.util.List;

import com.excel.poc.model.Student;

public interface StudentService {
	
	
	public List<Student> saveAllStudent(List<Student> students);

}
