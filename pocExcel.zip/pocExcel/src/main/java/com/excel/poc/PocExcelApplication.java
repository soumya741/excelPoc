package com.excel.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocExcelApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocExcelApplication.class, args);
	}

}
